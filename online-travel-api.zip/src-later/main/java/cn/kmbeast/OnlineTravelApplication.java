package cn.kmbeast;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("cn.kmbeast.mapper")
@SpringBootApplication
public class OnlineTravelApplication {
    public static void main(String[] args) {
        SpringApplication.run(OnlineTravelApplication.class, args);
    }
}
